
package timeManagerPackage;

//import
import acm.graphics.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.*;

import acm.io.*;
import acm.program.*;
import java.lang.*;
import javax.swing.*;

public class Main extends ConsoleProgram {

	public Main() {
		// TODO Auto-generated constructor stub
	}

	public void init() {
		// new timematrix with 15 minute intervals
		Organizer = new TimeMatrix(15);
		add(Organizer);
	}
	
	public void run() {
		// run method for executing stuff

		
		mainGraphics = new MainGraphics();

		// add values to the timematrix: use a JTextField
		valueAsker = new JTextField(30);
		println("1");
		pause(1000);
		// label it and add the text field
		add(new JLabel("New Event:"), SOUTH);
		add(valueAsker, SOUTH);
		println("1");
		pause(1000);
		// add listener for the valueAsker
		valueAsker.addActionListener(this);

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == valueAsker) {
			Organizer.addEntry(valueAsker.getText());
			//update the matrix: send timeInterval 15 and ArrayList from Organizer to mainGraphics to UpdateCanvas
			println(Organizer.returnToString().toString());
			//mainGraphics.UpdateCanvas(15, Organizer.eventList);
			
		}
	}

	// instance variables:
	JTextField valueAsker;
	MainGraphics mainGraphics;
	TimeMatrix Organizer;

}
