
package timeManagerPackage;

//import
import acm.graphics.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.*;

import acm.io.*;
import acm.program.*;
import java.lang.*;
import javax.swing.*;

public class Main extends ConsoleProgram {

	public Main() {
		// TODO Auto-generated constructor stub
	}

	public void init() {
		// new timematrix with 15 minute intervals
		Organizer = new TimeMatrix(readInt("Enter time (minutes) for each interval: "));
		add(Organizer);
	}
	
	public void run() {
		// run method for executing stuff

		
		mainGraphics = new MainGraphics();

		// add values to the timematrix: use a JTextField
		valueAsker = new JTextField(20);
		replaceAsker = new JTextField(20);
		replaceIndexAsker = new JTextField(2);
		
		// label it and add the text field
		add(new JLabel("New Event:"), SOUTH);
		add(valueAsker, SOUTH);
		add(new JLabel("Replace Event:"), SOUTH);
		add(replaceIndexAsker, SOUTH);
		add(new JLabel("With:"), SOUTH);
		add(replaceAsker, SOUTH);
		
		// add listener for the valueAsker
		valueAsker.addActionListener(this);
		replaceAsker.addActionListener(this);
		replaceIndexAsker.addActionListener(this);
		
		

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == valueAsker) {
			Organizer.addEntry(valueAsker.getText());
			//update the matrix: send timeInterval 15 and ArrayList from Organizer to mainGraphics to UpdateCanvas
			println(Organizer.returnToString().toString());
			
			//display to the matrix
			Organizer.MatrixDisplay();
			
			//mainGraphics.UpdateCanvas(15, Organizer.eventList);
			
			//clear the text box
			valueAsker.setText("");
		}
		//either if the source is the index asker or the replace asker
		else if (e.getSource() == replaceIndexAsker || e.getSource() == replaceAsker) {
			//store the index inputted to replace the value in the matrix
			replaceIndex = Integer.parseInt(replaceIndexAsker.getText());
			replaceIndexAsker.setText("");
			
			
			println(replaceIndex);
			
			//replace
			println(replaceAsker.getText());
			Organizer.replaceEntry(replaceAsker.getText(), replaceIndex);
			
			replaceAsker.setText("");
		}
		
		
	}

	// instance variables:
	JTextField valueAsker;
	JTextField replaceAsker;
	JTextField replaceIndexAsker;
	MainGraphics mainGraphics;
	TimeMatrix Organizer;
	
	//to track the index being replaced:
	int replaceIndex;

}
