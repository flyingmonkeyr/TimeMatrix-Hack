package timeManagerPackage;

//import
import acm.graphics.*;
import java.awt.*;
import java.awt.event.ActionEvent;

import acm.io.*;
import acm.program.*;
import java.lang.*;
import javax.swing.*;
import java.util.*;

public class MainGraphics extends GraphicsProgram{

	public MainGraphics() {
		// TODO Auto-generated constructor stub
		
	}
	
	//takes in an int for the time interval and an arraylist for copying over to the TimeMatrix in the class
	public void UpdateCanvas(int timeInterval, ArrayList<String> list) {
		timeInt = timeInterval;
		matrix = new TimeMatrix(timeInt);
		for (int i = 0; i < list.size(); i++) {
			matrix.addString(list.get(i));
		}
		//add the matrix to the screen
		matrix.MatrixDisplay();
		
	}
	
	//instance variables
	TimeMatrix matrix;
	int timeInt;

}
