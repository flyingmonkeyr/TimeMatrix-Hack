/**
 * 
 */
package timeManagerPackage;

//imports
import acm.graphics.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import acm.program.*;

/**
 * @author LenovoYoga
 *
 */
public class TimeMatrix extends GCanvas{

	/**
	 * 
	 */
	
	//runs each time a new TimeMatrix object is called
	public TimeMatrix(int timeIncrementLength) {
		// TODO Auto-generated constructor stub
		//store parameter value in instance variable
		timeLength = timeIncrementLength;
		
		
		
	}
	
	//adds the matrix display to the screen through a GCanvas
	public void MatrixDisplay() {
		//create the GCompound to be used
		//GCompound MatrixCompound = new GCompound();
		//cycle through the matrix and create a GCompound made of GRects with GLabels inside them indicating the event
		
		//error print
		//add(new GLabel("asfd"), 50, 50);
		
		for(int i = 0; i < eventList.size(); i++) {
			GRect labelHolder = new GRect(100, timeLength);
			add(labelHolder, 0, i*timeLength);
			labelSizeOffset = 4;
			GLabel label = new GLabel(eventList.get(i));
			label.setFont("SansSerif-" + (timeLength - labelSizeOffset));
			add(label, 5, i*timeLength + (timeLength - (0.5*labelSizeOffset)));
			
			//create a label to the side indicating time
			GLabel timeLabel = new GLabel(Integer.toString(timeLength));
			add(timeLabel, 105, (i+1)*timeLength + timeLabel.getHeight()/4);
		}
		
		//add(MatrixCompound);
		
	}
	
	public void addNextElement() {
		
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	//when called, adds the specified string into the array list
	public void addEntry(String entry) {
		
		//if the loc is -1 (impossible), add the entry to the end
		eventList.add(entry);
		
	}
	
	//replaces entry at loc with String entry
	public void replaceEntry(String entry, int loc) {
		
		//remove the old GLabel
		remove(getElementAt(5, ((timeLength*(loc-1)) + 13)));
		
		//error print(timeLength*(loc-1)
		GRect whiteRect = new GRect(100, timeLength);
		whiteRect.setFilled(true);
		whiteRect.setFillColor(Color.WHITE);
		add(whiteRect, 0, timeLength*(loc-1));
		
		//add the new GLabel
		GLabel newLabel = new GLabel(entry);
		newLabel.setFont("SansSerif-" + (timeLength - labelSizeOffset));
		add(newLabel, 5, (timeLength*(loc-1) + 13));
		
	}
	
	public String getValue(int index) {
		return eventList.get(index);
	}
	
	public void addString(String string) {
		eventList.add(string);
	}
	
	//to string: returns a printable version of eventList
	public String[] returnToString() {
		String[] timeMatrix = new String[eventList.size()];
		for (int i = 0; i < eventList.size(); i++) {
			timeMatrix[i] = eventList.get(i);
		}
		
		return timeMatrix;
	}
	
	//instance variables
	//create ArrayList to hold all the events of the working period
	public ArrayList <String> eventList = new ArrayList<String>();
	//store the time length of each working "block"
	public int timeLength;
	
	int labelSizeOffset;

}
