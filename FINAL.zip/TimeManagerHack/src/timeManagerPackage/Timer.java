package timeManagerPackage;

//import
import acm.graphics.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.*;

import acm.io.*;
import acm.program.*;
import java.lang.*;
import javax.swing.*;

public class Timer extends GraphicsProgram{

	public Timer(int timerValue) {
		// TODO Auto-generated constructor stub
		//start the timer
		startTime = System.currentTimeMillis();
		timerValueInstance = timerValue;
		
	}
	
	public String getTime() {
		//timer variables
		elapsedTime = System.currentTimeMillis() - startTime;
		elapsedSeconds = elapsedTime / 1000;
		secondsDisplay = elapsedSeconds % 60;
		elapsedMinutes = elapsedSeconds / 60;
		
		//return a string version of time
		return (Integer.toString((int)timerValueInstance - ((int)elapsedMinutes+1)) + "." + Integer.toString(60 - (int)secondsDisplay));
		
	}
	
	public void resetTime() {
		//reset the startTime
		startTime = System.currentTimeMillis();
	}
	
	public double time;
	
	
	public int timerValueInstance;
	public long startTime;
	public long elapsedTime;
	long elapsedSeconds;
	long secondsDisplay;
	public long elapsedMinutes;
	//put here code to format and display the values

}
