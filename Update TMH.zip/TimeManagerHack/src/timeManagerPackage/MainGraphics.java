package timeManagerPackage;

//import
import acm.graphics.*;
import java.awt.*;
import java.awt.event.ActionEvent;

import acm.io.*;
import acm.program.*;
import java.lang.*;
import javax.swing.*;

public class MainGraphics extends GraphicsProgram{

	public MainGraphics() {
		// TODO Auto-generated constructor stub
		
	}
	
	public void UpdateCanvas(int timeInterval, ArrayList list) {
		timeInt = timeInterval;
		matrix = new TimeMatrix(timeInt);
		for (int i = 0; i < matrix.eventList.size(); i++) {
			matrix.getValue(i);
		}
		
	}
	
	//instance variables
	TimeMatrix matrix;
	int timeInt;

}
